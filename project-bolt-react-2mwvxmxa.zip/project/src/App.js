import React from 'react';
import StockAnalyzer from './StockAnalyzer';

function App() {
  return <StockAnalyzer />;
}

export default App;
